<!DOCTYPE html>
<html>
<head><title>Key Verification</title></head>
<body>
<h2>Enter Key</h2>
<form action="key_verify.php" method="POST">
    <input type="text" name="key" required>
    <button type="submit">Verify</button>
</form>
</body>
</html>