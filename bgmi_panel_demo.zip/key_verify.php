<?php
$key = $_POST['key'];
$valid_keys = file('keys.txt', FILE_IGNORE_NEW_LINES);
if (in_array($key, $valid_keys)) {
    echo "Key is valid!";
} else {
    echo "Invalid key!";
}
?>